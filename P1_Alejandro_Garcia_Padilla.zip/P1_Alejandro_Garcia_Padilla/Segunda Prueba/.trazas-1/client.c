/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/main.c to edit this template
 */

/* 
 * File:   client.c
 * Author: alex
 * ©Alejandro_Garcia_Padilla_The_Ultimate_ASI_Laboratory_Guide
 * Created on 8 de febrero de 2024, 19:53
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>
#include <pthread.h>
#include <sys/wait.h>


/*Declaración de las funciones que resuelven los ejercicios*/
void espera(int *ejercicio); /*Nos indica que es conveniente esperar al accionado de una tecla por parte del usuario para avanzar*/
void ejercicio1(int pid_mon); /*le tenemos que pasar el pid del monitor para que le envie la señal*/
void ejercicio2(int pid_mon);
void atiendeSig2();
void ejercicio3(int pid_mon, int *contador, int *ejercicio); /*Dentro del ejercicio 3 ejecutaremos el 4 y el 5*/
void ejercicio4();
void ejercicio5(int pid_mon);
void ejercicio6(int pid_mon);
/*función para la creación de hilos asociada al ejercicio 4*/
void creaHilo();
/*función para "atender al hilo*/
void *muestraActividadHilo();
/*función para salir del bucle*/
void salirBucle();
void salirBucle1();
/*función para atender las señales que nos devuelve el monitor*/
void atiendeSignalUsr2();

/*Declaración de variables globales para hacer temporizadores y contadores*/
int temp20 = 0;
int cuenta_hilos = 0;
int pid_mon;
int paraproc = 0;
int paraproc1 = 0;
int secs = 20;
int cuenta_signals = 0;
int aux = 0;

int main(int argc, char** argv) {
    
    /*Lo primero que debemos hacer es recoger el pid dado por el monitor
     y convertirlo en un entero. Dicho PID será el segundo elemento del 
     array argv --> Array de chars --> necesitamos convertirlo a un int*/
    
    pid_mon = atoi(argv[1]);
    int ejercicio = 1; /*Nos va a marcar el ejercicio en que nos hayamos al pulsar la tecla*/
    
    
    espera(&ejercicio);
    ejercicio1(pid_mon);
    /*Le mandamos esperar para elegir el ejercicio 2*/
    espera(&ejercicio);
    ejercicio2(pid_mon);
    
    espera(&ejercicio);
    ejercicio3(pid_mon,&cuenta_hilos,&ejercicio);
    
    

    return (EXIT_SUCCESS);
}

void ejercicio1(int pid_mon){
    
    /*Enviar señal SIGUSR1 al monitor*/
    kill(pid_mon,SIGUSR1);
    /*Dormir durante 5 segundos*/
    sleep(5);
}

void espera(int *ejercicio){ /*Será puntero para poder modificarla*/
    printf("Pulsa tecla para ejecutar ejercicio %d :\n", *ejercicio);
    __fpurge(stdin);
    getchar();
    (*ejercicio)++; 
}

void ejercicio2(int pid_mon){
    /*Enviar señal SIGUSR1 al monitor*/
    kill(pid_mon,SIGUSR1);
    /*Recibir señal SIGUSR2 del monitor*/
    signal(SIGUSR2, atiendeSig2);
    /*Bloquear el proceso para que no haga nada hasta que reciba la señal*/
    pause();
}

void atiendeSig2(){
    /*Indicanos que has recibido la señal*/
    printf("Señal recibida correctamente!\n");
    /*Mandar eco de la señal*/
    kill(pid_mon,SIGUSR2); /*Solo se manda la señal una vez recibida la anterior*/
}

void ejercicio3(int pid_mon, int *contador, int *ejercicio){
    /*Enviar señal SIGUSR1 al monitor*/
    int exexec;
    kill(pid_mon,SIGUSR1);
    /*Espera 1 segundo*/
    sleep(1);
    /*Crea dos procesos hijos*/
    pid_t hijo1, hijo2; //*Solo podemos crear 2 hijos y estos son copia del padre por tanto no podremos hacerlo como previamente
    
    hijo1 = fork();
    
    switch (hijo1){
        
        case -1:
            printf("Error mate\n");
            break;
        
        case 0: 
            ejercicio4();
            exit(EXIT_SUCCESS);
            break;
        
        default: /*Soy el padre --> Pues genero el hijo 2*/
            
            hijo2 = fork();
            
            switch(hijo2){
                
                case -1:
                    printf("Error mate\n");
                    break;
                case 0:
                    ejercicio5(pid_mon);
                    break;
                    
                default:
                    kill(pid_mon,SIGUSR1);
                    espera(ejercicio);
                    espera(ejercicio);
                    /*Nada mas entres al 5 manda la señal*/
                    kill(pid_mon, SIGUSR1); 
                    wait(NULL);
                    wait(NULL);
                    espera(ejercicio);
                    ejercicio6(pid_mon);
                    exit(EXIT_SUCCESS);
                    break;
            } 
    }   
}


void ejercicio4(){
    
    signal(SIGALRM, salirBucle);
    alarm(20);
    while(paraproc == 0){
        signal(SIGUSR2, creaHilo);
        printf("A la espera de la señal\n");
        pause();
    }
    
}

void creaHilo(){
    pthread_t thread;
    pthread_create(&thread, NULL,muestraActividadHilo,NULL);
    cuenta_hilos ++;
}

void salirBucle(){
    paraproc = 1;
}

void salirBucle1(){
    paraproc1 = 1;
}

void *muestraActividadHilo(){

    while(secs >=0){
        printf("Hilo en ejecución: %d\n y se han creado hasta ahora: %d hilos\n", (int)pthread_self(), cuenta_hilos); /*Devuelve el hilo en ejecución*/
        secs = secs - 5;
        sleep(5);
    }
}

void ejercicio5(int pid_mon){
    /*Poner paraproc a 0 para poder iniciar y que asi luego pueda parar*/
    /*Avisar al monitor del inicio de la acción*/
    /*Esperar hasta que el monitor lo decida y atender dicha señal*/
    signal(SIGUSR1,salirBucle1);
    paraproc1 = 0;
    while(!paraproc1){
        pause();
    }
    signal(SIGUSR2, atiendeSignalUsr2);
    paraproc1 = 0;
    while(!paraproc1){
        pause();
    }
    printf("Ejercicio 5 ended, nº signals == %d\n",cuenta_signals);
    exit(EXIT_SUCCESS);
}



void atiendeSignalUsr2(){
    printf("Señal recibida correctamente\n");
    cuenta_signals ++;
    kill(pid_mon, SIGUSR2);
    
}

void ejercicio6(int pid_mon){
    kill(pid_mon, SIGUSR1);
    sleep(1);
}


