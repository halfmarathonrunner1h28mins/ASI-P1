#include <stdio.h>
#include <stdio_ext.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <pthread.h>
#include <ctype.h>
#define MSG_SIZE 10000

void signalHandler1();
void signalHandlerPater();
void convertirMayus(char *cad);
void muereHijo1();
void quitarSalto(char *cad);
void *rutTh1(void *arg);

int aux = 0;// Variable global para matar todos procesos y comunicaciones
int actfich = 0; //edita el fichero
int sign = 0;

int main()
{
    FILE *pf; //Declaración del puntero a fichero
    printf("Hello\n");
    pid_t idfc1, idfc2;
    idfc1 = fork(); //creamos el proceso hijo 1 
    
    if(idfc1 == 0){ //Comprobamos que nos hayamos frente al hijo 1
        pthread_t t1;

        signal(SIGUSR1, signalHandler1);
        pause();
        sign = 1;
        
        if(pthread_create(&t1,NULL,rutTh1,NULL) != 0){
            printf("Error en el thread");
            pthread_exit(EXIT_SUCCESS);
        }
        
        
        
        if(pthread_join(t1,NULL) != 0){
            perror("Thread join_1");
            pthread_exit(EXIT_SUCCESS);
        }
    

    }
    else{   
        //No soy el proceso hijo1 --> soy el padre --> vamos a crear el hijo 2, que estará atento al teclado.
        idfc2 = fork();
        
        if(idfc2 == 0){//Comprobamos que es el hijo 2 --> Si es el capturo lo que me digan por teclado
            printf("Soy el hijo 2\n");
            char buffer[256];
            printf("Esperando una cadena...\n");
            fgets(buffer, 256, stdin);
            quitarSalto(buffer);
            printf("La cadena elegida es: %s\n", buffer);
            int tam = sizeof(buffer);
                    
            pf = fopen("fichero.txt", "w");
            if(pf != (FILE*) NULL){
                printf("Fichero abierto\n");
                fwrite(&tam, sizeof(int), 1, pf);
                fwrite(buffer, sizeof(buffer), 1, pf);
                printf("Cadena escrita en fichero.txt\n");
            }
                    
            fclose(pf);
            printf("HIJO 2: Fichero cerrado\n");
            do{
                int switcher;
                printf("Deseas visualizar el fichero en Mayúsculas (1), al padre (2),  terminar la comunicación(3): \n");
                scanf("%d",&switcher);
            
                switch(switcher){
                    case 1:
                        printf("Se la mando al hijo1 para que actue sobre el fichero\n");
                        kill(idfc1, SIGUSR1);
                        sleep(2);
                        
                    break;
                    case 2:
                        printf("Se la mando al padre\n");
                        kill(getppid(), SIGUSR2);
                        sleep(2);
                        
                    break;
                    case 3:
                        printf("Fin de coms, cierre de forma ordenada\n");
                        printf("Muerto hijo 2\nMuerto padre\nMuerto hijo 1\n");
                        aux = 1;
                        kill(idfc1, SIGTERM);
                        kill(getppid(), SIGTERM);
                        sleep(2);
                        exit(EXIT_SUCCESS);  
                    break;
                    default:
                        
                    break;
                }
            }while(aux == 0);
        }
        else{
            /*Se pausa el padre hasta que los hijos terminen*/
            signal(SIGUSR2, signalHandlerPater);
            pause();
            signal(SIGTERM, SIG_DFL);
            pause();
            wait(NULL);
            wait(NULL);
        }
    }
    return (EXIT_SUCCESS);
}

void signalHandler1(){
    printf("Soy el hijo1 y voy a actuar sobre el fichero");
}

void signalHandlerPater(){
    printf("Soy el padre\n");
}

void convertirMayus(char *cad) {
    int i = 0;
    char c;
    while (cad[i]) {
        c = cad[i];
        cad[i] = toupper(c);
        i++;
    }
}
void muereHijo1(){
    printf("Murio Hijo 1\n");
}

void quitarSalto(char *cad) {
    if (cad[strlen(cad) - 1] == '\n')
        cad[strlen(cad) - 1] = '\0';
}

void *rutTh1(void *arg){
    
    while(sign == 0){
        usleep(100);   
    }
    FILE *pf;
    pf = fopen("fichero.txt","r");
    int tam;
        if(pf != (FILE*)NULL){
            printf("Fichero abierto\n");
            fread(&tam,sizeof(int),1,pf);
            char string_leida[tam];
            fread(string_leida, sizeof(string_leida),1,pf);
            convertirMayus(string_leida);
            printf("Cadena modificada: %s\n", string_leida); 
        }
    fclose(pf);
    printf("Fichero cerrado \n");
}  




